#!/bin/sh 
#
# Initialize installation variables for installing 
# software or a module file.
# 
# Defines variables:
# - INSTALLER_NAME
# - INSTALLLER_EMAIL
# - SOFTWARE_NAME
# - SOFTWARE_VERSION
# - TEMPLATE (path to template module file)
# - MODULES (path to module directory)
# - PREFIX (path to installation directory)
# - STOW (same as PREFIX)

###########################################
# You can define these variables here, otherwise
# the script will ask for your input:
#INSTALLER_NAME=""
#INSTALLER_EMAIL=""
#SOFTWARE_NAME=""
#SOFTWARE_VERSION=""
#SOFTWARE_URL=""

USERS=/home
USER_DIR=$USERS/$USER/software
USER_MODULES=$USER_DIR/modules
INSTALLER_NAME=$USER
INSTALLER_EMAIL=${USER}@irepertoire.com

#################################################################
# Check if variables are set above or in environment

# Ask user for input
while [[ -z $SOFTWARE_NAME || $SOFTWARE_NAME =~ \ + ]]; do

    echo -n "Enter the software name and press [ENTER]: "
    read SOFTWARE_NAME

    if [[ $SOFTWARE_NAME =~ \ + ]]; then
        echo 'ERROR: whitespace not allowed in software name!'
        unset SOFTWARE_NAME
    fi

done

# Ask user for input
while [[ -z $SOFTWARE_VERSION || $SOFTWARE_VERSION =~ \ + ]]; do

    echo -n "Enter the software version and press [ENTER]: "
    read SOFTWARE_VERSION

    if [[ $SOFTWARE_VERSION =~ \ + ]]; then
        echo 'ERROR: whitespace not allowed in software version!'
        unset SOFTWARE_VERSION
    fi

done

while [[ -z $SOFTWARE_URL || $SOFTWARE_URL =~ \ + ]]; do

    echo -n "Enter the software URL and press [ENTER]: "
    read SOFTWARE_URL

done

echo "---------------------------------"
echo "INSTALLER_NAME: ${INSTALLER_NAME}"
echo "INSTALLER_EMAIL: ${INSTALLER_EMAIL}"
echo "SOFTWARE_NAME: ${SOFTWARE_NAME}"
echo "SOFTWARE_SOFTWARE_VERSION: ${SOFTWARE_VERSION}"
echo "SOFTWARE_URL: ${SOFTWARE_URL}"
echo "---------------------------------"

#################################################################
TEMPLATE=$USER_DIR/module_template
MODULES=$USER_MODULES
PREFIX=${USER_DIR}/local/${SOFTWARE_NAME}/${SOFTWARE_VERSION}
STOW=PREFIX
