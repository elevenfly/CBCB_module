#!/bin/sh 
#
# Copy a module template file for a user software installation.
#
# After running, it may be necessary to further edit the
# module file to add dependencies, etc.
#
# INSTALLER_NAME and INSTALLER_EMAIL can be set using environment variables
# CBCB_SW_INSTALLER_NAME and CBCB_SW_INSTALLER_EMAIL
source /home/$USER/software/scripts/init_install_vars.sh

MODULEFILE=${SOFTWARE_NAME}/${SOFTWARE_VERSION}
cd $MODULES && mkdir -p ${SOFTWARE_NAME} && cp ${TEMPLATE} $MODULEFILE

if [[ -f $MODULEFILE ]]; then

    REPLACE_CMD="sed -i 's/SOFTWARE_NAME/${SOFTWARE_NAME}/g' $MODULEFILE"
    eval $REPLACE_CMD

    REPLACE_CMD="sed -i 's/SOFTWARE_VERSION/${SOFTWARE_VERSION}/g' $MODULEFILE"
    eval $REPLACE_CMD

    REPLACE_CMD="sed -i 's|SOFTWARE_URL|${SOFTWARE_URL}|g' $MODULEFILE"
    eval $REPLACE_CMD

    REPLACE_CMD="sed -i 's/INSTALLER_NAME/${INSTALLER_NAME}/g' $MODULEFILE"
    eval $REPLACE_CMD

    REPLACE_CMD="sed -i 's/INSTALLER_EMAIL/${INSTALLER_EMAIL}/g' $MODULEFILE"
    eval $REPLACE_CMD

    # Add module dependencies
    if [[ -n $MODULE_DEPS ]]; then
        REPLACE_CMD="sed -i 's|MODULE_DEPS|module add ${MODULE_DEPS}|g' $MODULEFILE"
    else
        REPLACE_CMD="sed -i 's/MODULE_DEPS//g' $MODULEFILE"
    fi
    eval $REPLACE_CMD


    echo "Go to ${MODULES}/${SOFTWARE_NAME} and edit ${SOFTWARE_VERSION} with any other settings needed."
else
    echo "ERROR: Could not install module file."
fi
