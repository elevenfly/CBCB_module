#! /usr/bin/env bash

cd $( dirname $0 )

ls ./ | while read software; do

    if [ ! -d ${software} ]; then
        continue
    fi

    cd ${software}

    ls ./ | while read item ; do
        if [ ${item} != "install_package.sh" ]; then
            rm -r ${item}
        fi
    done

    cd ../

done
