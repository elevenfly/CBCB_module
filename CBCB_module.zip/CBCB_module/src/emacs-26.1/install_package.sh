#!/bin/sh 
#
# Module installation helper script for user installations
#
# To use, copy to software directory in src/ and edit variables and configure
# options as needed. After running, it may be necessary to further edit the
# module file to add dependencies, etc.
#
# INSTALLER_NAME and INSTALLER_EMAIL can be set using environment variables
# CBCB_SW_INSTALLER_NAME and CBCB_SW_INSTALLER_EMAIL

source /usr/share/modules/init/bash
source /home/$USER/software/scripts/init_install_vars.sh

# clean up the environment, set dependencies
MODULE_DEPS=""
module purge
module add $MODULE_DEPS

mkdir -p ${PREFIX}

#rm build.log

./configure --with-pop --with-mailutils --prefix=${PREFIX} 2>&1 | tee -a build.log
configure_status=${PIPESTATUS[0]}

make 2>&1 | tee -a build.log
make_status=${PIPESTATUS[0]}

make install 2>&1 | tee -a build.log
make_install_status=${PIPESTATUS[0]}

if [[ $configure_status -ne 0 || $make_status -ne 0 || $make_install_status -ne 0 ]]; then
    echo "ERROR: ./configure; make; make install failed. Check build.log."
    exit 1
fi

echo "Finished installing, now copying the template module and setting a couple variables."
source /home/$USER/software/scripts/copy_module_template.sh
