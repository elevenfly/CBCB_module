#!/bin/sh 
#
# Module installation helper script for user installations
#
# To use, copy to software directory in src/ and edit variables and configure
# options as needed. After running, it may be necessary to further edit the
# module file to add dependencies, etc.
#
# INSTALLER_NAME and INSTALLER_EMAIL can be set using environment variables
# CBCB_SW_INSTALLER_NAME and CBCB_SW_INSTALLER_EMAIL

source /usr/share/modules/init/bash
source /home/$USER/software/scripts/init_install_vars.sh

# clean up the environment, set dependencies
MODULE_DEPS=""
module purge
module add $MODULE_DEPS
module add gcc/7.4.0

src_dir=`pwd`

if [[ ! -d $PREFIX ]]; then

    #svn co http://llvm.org/svn/llvm-project/llvm/tags/RELEASE_900/final llvm
    #cd llvm/tools
    #svn co http://llvm.org/svn/llvm-project/cfe/tags/RELEASE_900/final clang
    #cd ..
    #cd tools/clang/tools
    #svn co http://llvm.org/svn/llvm-project/clang-tools-extra/tags/RELEASE_900/final extra
    #cd ../../..
    #cd projects
    #svn co http://llvm.org/svn/llvm-project/compiler-rt/tags/RELEASE_900/final compiler-rt
    #cd ..
    #cd projects
    #svn co http://llvm.org/svn/llvm-project/libcxx/tags/RELEASE_900/final libcxx
    #svn co http://llvm.org/svn/llvm-project/libcxxabi/tags/RELEASE_900/final libcxxabi
    #cd ..


    git clone https://github.com/llvm/llvm-project.git

fi

mkdir -p ${PREFIX}


cd $PREFIX


cmake -DLLVM_ENABLE_PROJECTS=clang -G "Unix Makefiles" $src_dir/llvm-project/llvm


#rm build.log

#./configure \
         #--prefix=${PREFIX} 2>&1 | tee -a build.log
configure_status=${PIPESTATUS[0]}

make -j 10 2>&1 | tee -a build.log
make_status=${PIPESTATUS[0]}
make -j 10 clang

#make install 2>&1 | tee -a build.log
make_install_status=${PIPESTATUS[0]}

#make -j 10 check-clang
#make_install_status=${PIPESTATUS[0]}

if [[ $configure_status -ne 0 || $make_status -ne 0 || $make_install_status -ne 0 ]]; then
    echo "ERROR: ./configure; make; make install failed. Check build.log."
    exit 1
fi

echo "Finished installing, now copying the template module and setting a couple variables."
source /home/$USER/software/scripts/copy_module_template.sh
